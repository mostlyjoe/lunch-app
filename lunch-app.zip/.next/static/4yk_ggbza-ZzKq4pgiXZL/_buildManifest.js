self.__BUILD_MANIFEST = {
  "/": [
    "./static/chunks/2181b23680ec3631.js"
  ],
  "/_error": [
    "./static/chunks/7a7c93af9c2ceb3c.js"
  ],
  "/admin": [
    "./static/chunks/5bb2cca0fa2ee8c0.js"
  ],
  "/admin/menu": [
    "./static/chunks/d6884dd55e044a95.js"
  ],
  "/admin/orders": [
    "./static/chunks/182643516eedc365.js"
  ],
  "/admin/orders-by-shift": [
    "./static/chunks/7322249a94b9a038.js"
  ],
  "/admin/profiles": [
    "./static/chunks/b8f93705c7d94382.js"
  ],
  "/auth": [
    "./static/chunks/800e5c75bad79dd4.js"
  ],
  "/login": [
    "./static/chunks/fb904b356e58a890.js"
  ],
  "/menu": [
    "./static/chunks/224f81dd18d9bd53.js"
  ],
  "/menu/[id]": [
    "./static/chunks/57bb94b0d5d97d27.js"
  ],
  "/orders": [
    "./static/chunks/d1b06531fb3b4f89.js"
  ],
  "/profile": [
    "./static/chunks/79052ea4e1e3c435.js"
  ],
  "/signup": [
    "./static/chunks/d088e8131fb4f5cd.js"
  ],
  "/test-icon": [
    "./static/chunks/aa6878f2ede9a8fa.js"
  ],
  "/under-construction": [
    "./static/chunks/e62e5eecfc77e1da.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/admin",
    "/admin/menu",
    "/admin/orders",
    "/admin/orders-by-shift",
    "/admin/profiles",
    "/api/deleteUser",
    "/api/hello",
    "/api/signup",
    "/auth",
    "/login",
    "/menu",
    "/menu/[id]",
    "/orders",
    "/profile",
    "/signup",
    "/test-icon",
    "/under-construction"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()
__turbopack_load_page_chunks__("/admin/orders-by-shift", [
  "static/chunks/76c8ffbddae8e85d.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-5107f8a6796af88d.js"
])

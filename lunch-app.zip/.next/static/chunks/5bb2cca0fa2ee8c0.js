__turbopack_load_page_chunks__("/admin", [
  "static/chunks/a89d83af5697ab8a.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-fc69bf552e636bde.js"
])

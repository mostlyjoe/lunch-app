__turbopack_load_page_chunks__("/orders", [
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1154706d9a0abfce.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-a71157bbdb4a2718.js"
])

__turbopack_load_page_chunks__("/admin/menu", [
  "static/chunks/d154811af63e8831.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-814c2818a4dd0b24.js"
])

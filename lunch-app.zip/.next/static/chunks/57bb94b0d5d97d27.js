__turbopack_load_page_chunks__("/menu/[id]", [
  "static/chunks/5fb4841170945186.js",
  "static/chunks/b8015d5c093222e6.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-0d552db7b414fffe.js"
])

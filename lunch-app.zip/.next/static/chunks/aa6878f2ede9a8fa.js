__turbopack_load_page_chunks__("/test-icon", [
  "static/chunks/260f2ed4938feae2.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-06a438987876f746.js"
])

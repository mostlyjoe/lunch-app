__turbopack_load_page_chunks__("/menu", [
  "static/chunks/1b61915d71c3c442.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-8d27f4404e6de5e2.js"
])

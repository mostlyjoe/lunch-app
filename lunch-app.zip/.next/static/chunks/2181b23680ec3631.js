__turbopack_load_page_chunks__("/", [
  "static/chunks/5fb4841170945186.js",
  "static/chunks/0c8aa34d573bf77b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-09cc997f24865d57.js"
])

__turbopack_load_page_chunks__("/under-construction", [
  "static/chunks/f20b004c5b6e819c.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-e8dd0842f6403145.js"
])

__turbopack_load_page_chunks__("/login", [
  "static/chunks/0f99d1fd5e472698.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-fabf234203bebeef.js"
])

__turbopack_load_page_chunks__("/_app", [
  "static/chunks/5fb4841170945186.js",
  "static/chunks/00d1cf0cedcb38c4.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/bc5ef8b5513f4c7d.css",
  "static/chunks/turbopack-fb735ca0765f2b9e.js"
])

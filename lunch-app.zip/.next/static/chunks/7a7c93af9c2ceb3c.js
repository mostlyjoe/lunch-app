__turbopack_load_page_chunks__("/_error", [
  "static/chunks/c43e26fcff9a124b.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-7110c7ae9def0688.js"
])

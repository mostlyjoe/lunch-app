__turbopack_load_page_chunks__("/auth", [
  "static/chunks/b91bc0a911998b6c.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-edce75778dbfd436.js"
])

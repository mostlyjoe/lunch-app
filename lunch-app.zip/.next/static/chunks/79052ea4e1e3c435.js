__turbopack_load_page_chunks__("/profile", [
  "static/chunks/5ea444793c396eb2.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-b9fddfb457dec0c7.js"
])

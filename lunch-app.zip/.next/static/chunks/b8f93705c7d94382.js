__turbopack_load_page_chunks__("/admin/profiles", [
  "static/chunks/6175fd9e9101773d.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-d1ad4d336ce4243c.js"
])

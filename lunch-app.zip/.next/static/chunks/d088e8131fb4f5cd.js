__turbopack_load_page_chunks__("/signup", [
  "static/chunks/02427af00fc298b8.js",
  "static/chunks/5fb4841170945186.js",
  "static/chunks/a75daff6d7941a9c.js",
  "static/chunks/1f812b127dfe102b.js",
  "static/chunks/ad1c5137710d442c.js",
  "static/chunks/turbopack-420028d30c300c9e.js"
])

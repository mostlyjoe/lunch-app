globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/5fb4841170945186.js",
      "static/chunks/0c8aa34d573bf77b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-09cc997f24865d57.js"
    ],
    "/_app": [
      "static/chunks/5fb4841170945186.js",
      "static/chunks/00d1cf0cedcb38c4.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/bc5ef8b5513f4c7d.css",
      "static/chunks/turbopack-fb735ca0765f2b9e.js"
    ],
    "/_error": [
      "static/chunks/c43e26fcff9a124b.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-7110c7ae9def0688.js"
    ],
    "/admin": [
      "static/chunks/a89d83af5697ab8a.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-fc69bf552e636bde.js"
    ],
    "/admin/menu": [
      "static/chunks/d154811af63e8831.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-814c2818a4dd0b24.js"
    ],
    "/admin/orders": [
      "static/chunks/e09f4da2ba6c58e1.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-874847374252d709.js"
    ],
    "/admin/orders-by-shift": [
      "static/chunks/76c8ffbddae8e85d.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-5107f8a6796af88d.js"
    ],
    "/admin/profiles": [
      "static/chunks/6175fd9e9101773d.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-d1ad4d336ce4243c.js"
    ],
    "/auth": [
      "static/chunks/b91bc0a911998b6c.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-edce75778dbfd436.js"
    ],
    "/login": [
      "static/chunks/0f99d1fd5e472698.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-fabf234203bebeef.js"
    ],
    "/menu": [
      "static/chunks/1b61915d71c3c442.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-8d27f4404e6de5e2.js"
    ],
    "/menu/[id]": [
      "static/chunks/5fb4841170945186.js",
      "static/chunks/b8015d5c093222e6.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-0d552db7b414fffe.js"
    ],
    "/orders": [
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1154706d9a0abfce.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-a71157bbdb4a2718.js"
    ],
    "/profile": [
      "static/chunks/5ea444793c396eb2.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-b9fddfb457dec0c7.js"
    ],
    "/signup": [
      "static/chunks/02427af00fc298b8.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/a75daff6d7941a9c.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-420028d30c300c9e.js"
    ],
    "/test-icon": [
      "static/chunks/260f2ed4938feae2.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-06a438987876f746.js"
    ],
    "/under-construction": [
      "static/chunks/f20b004c5b6e819c.js",
      "static/chunks/5fb4841170945186.js",
      "static/chunks/1f812b127dfe102b.js",
      "static/chunks/ad1c5137710d442c.js",
      "static/chunks/turbopack-e8dd0842f6403145.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
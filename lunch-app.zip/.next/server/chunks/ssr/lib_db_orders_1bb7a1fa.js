module.exports=[9545,a=>{"use strict";a.s(["calculateOrderTotals",()=>i,"deleteOrder",()=>f,"getAllOrders",()=>h,"getUserOrderForItem",()=>d,"getUserOrders",()=>c,"updateOrder",()=>g,"upsertOrder",()=>e]);var b=a.i(9190);async function c(a){let{data:c,error:d}=await b.supabase.from("orders").select(`
            id,
            user_id,
            menu_item_id,
            quantity,
            unit_price,
            status,
            created_at,
            menu_items (
                id,
                title,
                description,
                price,
                serve_date,
                order_deadline,
                image_url,
                is_active
            )
        `).eq("user_id",a).order("created_at",{ascending:!1});if(d)throw d;return c||[]}async function d(a,c){let{data:d,error:e}=await b.supabase.from("orders").select("*").eq("user_id",a).eq("menu_item_id",c).maybeSingle();if(e)throw e;return d}async function e(a){let{data:c,error:d}=await b.supabase.from("orders").upsert(a,{onConflict:["user_id","menu_item_id"]}).select().single();if(d)throw d;return c}async function f(a){let{error:c}=await b.supabase.from("orders").delete().eq("id",a);if(c)throw c;return!0}async function g(a,c){let{error:d}=await b.supabase.from("orders").update(c).eq("id",a);if(d)throw d;return!0}async function h(){let{data:a,error:c}=await b.supabase.from("orders").select(`
            id,
            user_id,
            menu_item_id,
            quantity,
            unit_price,
            status,
            created_at,
            menu_items (
                id,
                title,
                serve_date,
                order_deadline,
                is_active
            ),
            profiles (
                id,
                first_name,
                last_name,
                shift_type
            )
        `).order("created_at",{ascending:!1});if(c)throw console.error("getAllOrders error:",c),c;return a||[]}function i(a){let b=(a.quantity||0)*(parseFloat(a.unit_price)||0),c=.13*b,d=b+c;return{subtotal:b.toFixed(2),tax:c.toFixed(2),total:d.toFixed(2)}}}];

//# sourceMappingURL=lib_db_orders_1bb7a1fa.js.map
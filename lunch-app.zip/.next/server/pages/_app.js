var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[externals]_@supabase_supabase-js_71badcb7._.js")
R.c("server/chunks/ssr/[root-of-the-server]__60c6e5a4._.js")
R.c("server/chunks/ssr/[root-of-the-server]__56e741ad._.js")
R.m(7342)
module.exports=R.m(7342).exports

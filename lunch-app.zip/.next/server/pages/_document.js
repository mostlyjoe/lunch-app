var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[externals]_next_dist_compiled_@opentelemetry_api_2f2eda7e._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0a3a2a0c._.js")
R.c("server/chunks/ssr/[root-of-the-server]__68d47023._.js")
R.m(1224)
module.exports=R.m(1224).exports

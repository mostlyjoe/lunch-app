var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/signup.js")
R.c("server/chunks/[root-of-the-server]__b65fcadd._.js")
R.c("server/chunks/[root-of-the-server]__ec476382._.js")
R.m(2088)
module.exports=R.m(2088).exports

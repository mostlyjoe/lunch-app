var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/deleteUser.js")
R.c("server/chunks/[root-of-the-server]__a8f79c3d._.js")
R.c("server/chunks/[root-of-the-server]__ec476382._.js")
R.m(471)
module.exports=R.m(471).exports
